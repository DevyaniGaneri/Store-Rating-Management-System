const express = require('express');
const router = express.Router();
const {
  getDashboardStats,
  createUser,
  createStore,
  listUsers,
  getUserById,
  listStores,
} = require('../controllers/adminController');
const { protect, authorize } = require('../middleware/auth');

// All routes below require an authenticated System Administrator
router.use(protect, authorize('ADMIN'));

router.get('/dashboard', getDashboardStats);

router.post('/users', createUser);
router.get('/users', listUsers);
router.get('/users/:id', getUserById);

router.post('/stores', createStore);
router.get('/stores', listStores);

module.exports = router;
