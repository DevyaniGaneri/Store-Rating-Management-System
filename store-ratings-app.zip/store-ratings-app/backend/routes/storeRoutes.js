const express = require('express');
const router = express.Router();
const { listStoresForUser, getOwnerDashboard } = require('../controllers/storeController');
const { protect, authorize } = require('../middleware/auth');

// Normal user store listing (search + own rating)
router.get('/', protect, authorize('USER'), listStoresForUser);

// Store owner dashboard
router.get('/owner/dashboard', protect, authorize('STORE_OWNER'), getOwnerDashboard);

module.exports = router;
