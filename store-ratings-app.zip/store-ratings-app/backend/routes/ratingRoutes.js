const express = require('express');
const router = express.Router();
const { submitRating, deleteRating } = require('../controllers/ratingController');
const { protect, authorize } = require('../middleware/auth');

router.post('/', protect, authorize('USER'), submitRating);
router.delete('/:storeId', protect, authorize('USER'), deleteRating);

module.exports = router;
