const bcrypt = require('bcryptjs');
require('dotenv').config();
const sequelize = require('../config/db');
const { User } = require('../models');

async function seed() {
  try {
    await sequelize.authenticate();
    await sequelize.sync();

    const email = process.env.ADMIN_EMAIL;
    const existing = await User.findOne({ where: { email } });

    if (existing) {
      console.log(`Admin account already exists for ${email}. Skipping.`);
      process.exit(0);
    }

    const hashedPassword = await bcrypt.hash(process.env.ADMIN_PASSWORD, 10);

    await User.create({
      name: process.env.ADMIN_NAME,
      email,
      password: hashedPassword,
      address: process.env.ADMIN_ADDRESS,
      role: 'ADMIN',
    });

    console.log('✔ System Administrator account created successfully:');
    console.log(`  Email:    ${email}`);
    console.log(`  Password: ${process.env.ADMIN_PASSWORD}`);
    process.exit(0);
  } catch (err) {
    console.error('Failed to seed admin account:', err);
    process.exit(1);
  }
}

seed();
