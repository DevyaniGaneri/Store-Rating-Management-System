const { Op, fn, col } = require('sequelize');
const { Store, Rating, User } = require('../models');

const SORTABLE_FIELDS = ['name', 'address', 'averageRating'];

// @route  GET /api/stores
// @desc   Normal user: list stores with search by name/address, overall rating,
//         and the logged-in user's own submitted rating (if any)
exports.listStoresForUser = async (req, res) => {
  try {
    const { name, address, sortBy = 'name', sortOrder = 'ASC' } = req.query;

    const where = {};
    if (name) where.name = { [Op.iLike]: `%${name}%` };
    if (address) where.address = { [Op.iLike]: `%${address}%` };

    const stores = await Store.findAll({
      where,
      include: [{ model: Rating, as: 'ratings', attributes: ['rating', 'user_id'] }],
    });

    const userId = req.user.id;

    let mapped = stores.map((store) => {
      const ratings = store.ratings || [];
      const count = ratings.length;
      const avg = count > 0 ? ratings.reduce((sum, r) => sum + r.rating, 0) / count : null;
      const myRating = ratings.find((r) => r.user_id === userId);

      return {
        id: store.id,
        name: store.name,
        email: store.email,
        address: store.address,
        averageRating: avg !== null ? parseFloat(avg.toFixed(2)) : null,
        ratingCount: count,
        myRating: myRating ? myRating.rating : null,
      };
    });

    const orderField = SORTABLE_FIELDS.includes(sortBy) ? sortBy : 'name';
    const dir = sortOrder.toUpperCase() === 'DESC' ? -1 : 1;
    mapped = mapped.sort((a, b) => {
      let av = a[orderField];
      let bv = b[orderField];
      if (av === null) av = orderField === 'averageRating' ? -1 : '';
      if (bv === null) bv = orderField === 'averageRating' ? -1 : '';
      if (av < bv) return -1 * dir;
      if (av > bv) return 1 * dir;
      return 0;
    });

    return res.json({ stores: mapped });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Failed to fetch stores' });
  }
};

// @route  GET /api/stores/owner/dashboard
// @desc   Store Owner: view average rating and list of users who rated their store
exports.getOwnerDashboard = async (req, res) => {
  try {
    const store = await Store.findOne({ where: { owner_id: req.user.id } });

    if (!store) {
      return res.status(404).json({ message: 'No store is currently linked to your account.' });
    }

    const ratings = await Rating.findAll({
      where: { store_id: store.id },
      include: [{ model: User, as: 'user', attributes: ['id', 'name', 'email', 'address'] }],
      order: [['createdAt', 'DESC']],
    });

    const count = ratings.length;
    const avg = count > 0 ? ratings.reduce((sum, r) => sum + r.rating, 0) / count : 0;

    return res.json({
      store: { id: store.id, name: store.name, email: store.email, address: store.address },
      averageRating: parseFloat(avg.toFixed(2)),
      totalRatings: count,
      raters: ratings.map((r) => ({
        ratingId: r.id,
        rating: r.rating,
        submittedAt: r.createdAt,
        user: r.user,
      })),
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Failed to load store owner dashboard' });
  }
};
