const bcrypt = require('bcryptjs');
const { Op, fn, col, literal } = require('sequelize');
const { User, Store, Rating, sequelize } = require('../models');
const {
  validateName,
  validateAddress,
  validateEmail,
  validatePassword,
} = require('../utils/validators');

const SORTABLE_USER_FIELDS = ['name', 'email', 'address', 'role', 'createdAt'];
const SORTABLE_STORE_FIELDS = ['name', 'email', 'address', 'createdAt', 'averageRating'];

// @route  GET /api/admin/dashboard
exports.getDashboardStats = async (req, res) => {
  try {
    const [totalUsers, totalStores, totalRatings] = await Promise.all([
      User.count(),
      Store.count(),
      Rating.count(),
    ]);

    return res.json({ totalUsers, totalStores, totalRatings });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Failed to load dashboard statistics' });
  }
};

// @route  POST /api/admin/users
// @desc   Admin creates a new user (Normal User, Admin, or Store Owner)
exports.createUser = async (req, res) => {
  try {
    const { name, email, address, password, role, storeId } = req.body;

    const errors = {};
    const nameErr = validateName(name);
    const emailErr = validateEmail(email);
    const addressErr = validateAddress(address);
    const passwordErr = validatePassword(password);
    if (nameErr) errors.name = nameErr;
    if (emailErr) errors.email = emailErr;
    if (addressErr) errors.address = addressErr;
    if (passwordErr) errors.password = passwordErr;

    const allowedRoles = ['ADMIN', 'USER', 'STORE_OWNER'];
    if (!allowedRoles.includes(role)) {
      errors.role = 'Role must be one of ADMIN, USER, STORE_OWNER';
    }

    if (Object.keys(errors).length > 0) {
      return res.status(400).json({ message: 'Validation failed', errors });
    }

    const existing = await User.findOne({ where: { email } });
    if (existing) {
      return res.status(409).json({ message: 'A user with this email already exists.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, address, password: hashedPassword, role });

    // Optionally link a newly created STORE_OWNER to an existing store
    if (role === 'STORE_OWNER' && storeId) {
      const store = await Store.findByPk(storeId);
      if (store) {
        store.owner_id = user.id;
        await store.save();
      }
    }

    return res.status(201).json({
      message: 'User created successfully',
      user: { id: user.id, name: user.name, email: user.email, address: user.address, role: user.role },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error while creating user' });
  }
};

// @route  POST /api/admin/stores
// @desc   Admin creates a new store
exports.createStore = async (req, res) => {
  try {
    const { name, email, address, ownerId } = req.body;

    const errors = {};
    if (!name || name.trim().length === 0 || name.length > 60) {
      errors.name = 'Store name is required and must be at most 60 characters';
    }
    const emailErr = validateEmail(email);
    const addressErr = validateAddress(address);
    if (emailErr) errors.email = emailErr;
    if (addressErr) errors.address = addressErr;

    if (Object.keys(errors).length > 0) {
      return res.status(400).json({ message: 'Validation failed', errors });
    }

    const existing = await Store.findOne({ where: { email } });
    if (existing) {
      return res.status(409).json({ message: 'A store with this email already exists.' });
    }

    let owner_id = null;
    if (ownerId) {
      const owner = await User.findOne({ where: { id: ownerId, role: 'STORE_OWNER' } });
      if (!owner) {
        return res.status(400).json({ message: 'Selected owner must be an existing Store Owner user.' });
      }
      owner_id = owner.id;
    }

    const store = await Store.create({ name, email, address, owner_id });

    return res.status(201).json({ message: 'Store created successfully', store });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error while creating store' });
  }
};

// @route  GET /api/admin/users
// @desc   List users with filters (name, email, address, role) and sorting
exports.listUsers = async (req, res) => {
  try {
    const { name, email, address, role, sortBy = 'createdAt', sortOrder = 'DESC' } = req.query;

    const where = {};
    if (name) where.name = { [Op.iLike]: `%${name}%` };
    if (email) where.email = { [Op.iLike]: `%${email}%` };
    if (address) where.address = { [Op.iLike]: `%${address}%` };
    if (role) where.role = role;

    const orderField = SORTABLE_USER_FIELDS.includes(sortBy) ? sortBy : 'createdAt';
    const orderDir = sortOrder.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    const users = await User.findAll({
      where,
      attributes: { exclude: ['password'] },
      order: [[orderField, orderDir]],
    });

    return res.json({ users });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Failed to fetch users' });
  }
};

// @route  GET /api/admin/users/:id
// @desc   View a single user's details. If Store Owner, include their store's rating.
exports.getUserById = async (req, res) => {
  try {
    const user = await User.findByPk(req.params.id, {
      attributes: { exclude: ['password'] },
      include: [{ model: Store, as: 'ownedStore' }],
    });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    let rating = null;
    if (user.role === 'STORE_OWNER' && user.ownedStore) {
      const result = await Rating.findOne({
        where: { store_id: user.ownedStore.id },
        attributes: [[fn('AVG', col('rating')), 'avgRating'], [fn('COUNT', col('rating')), 'count']],
        raw: true,
      });
      rating = {
        average: result.avgRating ? parseFloat(result.avgRating).toFixed(2) : null,
        count: parseInt(result.count, 10) || 0,
      };
    }

    return res.json({ user, rating });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Failed to fetch user details' });
  }
};

// @route  GET /api/admin/stores
// @desc   List stores with filters (name, email, address) and sorting, including average rating
exports.listStores = async (req, res) => {
  try {
    const { name, email, address, sortBy = 'createdAt', sortOrder = 'DESC' } = req.query;

    const where = {};
    if (name) where.name = { [Op.iLike]: `%${name}%` };
    if (email) where.email = { [Op.iLike]: `%${email}%` };
    if (address) where.address = { [Op.iLike]: `%${address}%` };

    const orderField = SORTABLE_STORE_FIELDS.includes(sortBy) ? sortBy : 'createdAt';
    const orderDir = sortOrder.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    const stores = await Store.findAll({
      where,
      attributes: {
        include: [
          [fn('ROUND', fn('AVG', col('ratings.rating')), 2), 'averageRating'],
          [fn('COUNT', col('ratings.id')), 'ratingCount'],
        ],
      },
      include: [{ model: Rating, as: 'ratings', attributes: [] }],
      group: ['Store.id'],
      subQuery: false,
      order: orderField === 'averageRating'
        ? [[literal('"averageRating"'), orderDir]]
        : [[orderField, orderDir]],
    });

    return res.json({ stores });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Failed to fetch stores' });
  }
};
