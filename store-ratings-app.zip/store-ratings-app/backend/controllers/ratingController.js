const { Rating, Store } = require('../models');
const { validateRatingValue } = require('../utils/validators');

// @route  POST /api/ratings
// @desc   Normal user submits or updates a rating (1-5) for a store
exports.submitRating = async (req, res) => {
  try {
    const { storeId, rating } = req.body;

    const ratingErr = validateRatingValue(rating);
    if (ratingErr) {
      return res.status(400).json({ message: 'Validation failed', errors: { rating: ratingErr } });
    }

    const store = await Store.findByPk(storeId);
    if (!store) {
      return res.status(404).json({ message: 'Store not found' });
    }

    const [record, created] = await Rating.findOrCreate({
      where: { user_id: req.user.id, store_id: storeId },
      defaults: { rating: Number(rating) },
    });

    if (!created) {
      record.rating = Number(rating);
      await record.save();
    }

    return res.status(created ? 201 : 200).json({
      message: created ? 'Rating submitted successfully' : 'Rating updated successfully',
      rating: record,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error while submitting rating' });
  }
};

// @route  DELETE /api/ratings/:storeId
// @desc   Normal user removes their rating for a store
exports.deleteRating = async (req, res) => {
  try {
    const deleted = await Rating.destroy({
      where: { user_id: req.user.id, store_id: req.params.storeId },
    });
    if (!deleted) {
      return res.status(404).json({ message: 'Rating not found' });
    }
    return res.json({ message: 'Rating removed successfully' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error while deleting rating' });
  }
};
