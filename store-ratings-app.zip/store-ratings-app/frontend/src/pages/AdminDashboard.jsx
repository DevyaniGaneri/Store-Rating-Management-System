import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/axios';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/admin/dashboard')
      .then(({ data }) => setStats(data))
      .catch(() => setError('Failed to load dashboard statistics.'));
  }, []);

  return (
    <div className="page-container">
      <h1 className="page-title">Administrator Dashboard</h1>
      <p className="page-subtitle">Platform-wide overview and quick actions</p>

      {error && <div className="alert alert-error">{error}</div>}

      {stats && (
        <div className="stats-grid">
          <div className="stat-card">
            <span className="stat-value">{stats.totalUsers}</span>
            <span className="stat-label">Total Users</span>
          </div>
          <div className="stat-card">
            <span className="stat-value">{stats.totalStores}</span>
            <span className="stat-label">Total Stores</span>
          </div>
          <div className="stat-card">
            <span className="stat-value">{stats.totalRatings}</span>
            <span className="stat-label">Total Ratings Submitted</span>
          </div>
        </div>
      )}

      <div className="quick-actions">
        <Link to="/admin/users/new" className="action-card">
          <h3>+ Add New User</h3>
          <p>Create Admin, Normal User, or Store Owner accounts</p>
        </Link>
        <Link to="/admin/stores/new" className="action-card">
          <h3>+ Add New Store</h3>
          <p>Register a new store on the platform</p>
        </Link>
        <Link to="/admin/users" className="action-card">
          <h3>Manage Users</h3>
          <p>View, filter, and inspect all registered users</p>
        </Link>
        <Link to="/admin/stores" className="action-card">
          <h3>Manage Stores</h3>
          <p>View, filter, and inspect all registered stores</p>
        </Link>
      </div>
    </div>
  );
}
