import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/axios';

export default function AdminAddStore() {
  const [form, setForm] = useState({ name: '', email: '', address: '', ownerId: '' });
  const [owners, setOwners] = useState([]);
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    api.get('/admin/users', { params: { role: 'STORE_OWNER' } })
      .then(({ data }) => setOwners(data.users))
      .catch(() => {});
  }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const validate = () => {
    const errs = {};
    if (form.name.trim().length === 0 || form.name.length > 60) {
      errs.name = 'Store name is required (max 60 characters)';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      errs.email = 'Enter a valid email address';
    }
    if (form.address.trim().length === 0 || form.address.length > 400) {
      errs.address = 'Address is required (max 400 characters)';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setServerError('');
    setSuccess('');
    if (!validate()) return;

    setLoading(true);
    try {
      await api.post('/admin/stores', form);
      setSuccess('Store created successfully.');
      setTimeout(() => navigate('/admin/stores'), 1000);
    } catch (err) {
      if (err.response?.data?.errors) setErrors(err.response.data.errors);
      else setServerError(err.response?.data?.message || 'Failed to create store.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container narrow">
      <h1 className="page-title">Add New Store</h1>
      <p className="page-subtitle">Register a new store on the platform</p>

      <div className="card">
        {serverError && <div className="alert alert-error">{serverError}</div>}
        {success && <div className="alert alert-success">{success}</div>}

        <form onSubmit={handleSubmit} className="auth-form" noValidate>
          <label>
            Store Name
            <input type="text" name="name" value={form.name} onChange={handleChange} maxLength={60} />
            {errors.name && <span className="field-error">{errors.name}</span>}
          </label>

          <label>
            Store Email
            <input type="email" name="email" value={form.email} onChange={handleChange} />
            {errors.email && <span className="field-error">{errors.email}</span>}
          </label>

          <label>
            Address
            <textarea name="address" value={form.address} onChange={handleChange} rows={3} maxLength={400} />
            {errors.address && <span className="field-error">{errors.address}</span>}
          </label>

          <label>
            Assign Store Owner (optional)
            <select name="ownerId" value={form.ownerId} onChange={handleChange}>
              <option value="">-- No owner assigned yet --</option>
              {owners.map((o) => (
                <option key={o.id} value={o.id}>{o.name} ({o.email})</option>
              ))}
            </select>
          </label>

          <button type="submit" className="btn btn-primary btn-block" disabled={loading}>
            {loading ? 'Creating…' : 'Create Store'}
          </button>
        </form>
      </div>
    </div>
  );
}
