import React, { useEffect, useState, useCallback } from 'react';
import api from '../api/axios';
import { StarDisplay, StarInput } from '../components/StarRating';

export default function StoreList() {
  const [stores, setStores] = useState([]);
  const [filters, setFilters] = useState({ name: '', address: '' });
  const [sortBy, setSortBy] = useState('name');
  const [sortOrder, setSortOrder] = useState('ASC');
  const [error, setError] = useState('');
  const [savingId, setSavingId] = useState(null);
  const [message, setMessage] = useState('');

  const fetchStores = useCallback(async () => {
    try {
      const params = { ...filters, sortBy, sortOrder };
      Object.keys(params).forEach((k) => !params[k] && delete params[k]);
      const { data } = await api.get('/stores', { params });
      setStores(data.stores);
    } catch (err) {
      setError('Failed to load stores.');
    }
  }, [filters, sortBy, sortOrder]);

  useEffect(() => { fetchStores(); }, [fetchStores]);

  const handleRate = async (storeId, rating) => {
    setSavingId(storeId);
    setMessage('');
    try {
      await api.post('/ratings', { storeId, rating });
      setMessage('Your rating has been saved.');
      fetchStores();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to submit rating.');
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div className="page-container">
      <h1 className="page-title">Browse Stores</h1>
      <p className="page-subtitle">Search stores and share your rating with the community</p>

      {error && <div className="alert alert-error">{error}</div>}
      {message && <div className="alert alert-success">{message}</div>}

      <div className="filter-bar">
        <input placeholder="Search by store name" value={filters.name} onChange={(e) => setFilters({ ...filters, name: e.target.value })} />
        <input placeholder="Search by address" value={filters.address} onChange={(e) => setFilters({ ...filters, address: e.target.value })} />
        <select value={`${sortBy}:${sortOrder}`} onChange={(e) => { const [f, o] = e.target.value.split(':'); setSortBy(f); setSortOrder(o); }}>
          <option value="name:ASC">Name (A–Z)</option>
          <option value="name:DESC">Name (Z–A)</option>
          <option value="averageRating:DESC">Highest Rated</option>
          <option value="averageRating:ASC">Lowest Rated</option>
        </select>
      </div>

      <div className="store-grid">
        {stores.length === 0 && <p className="empty-message">No stores match your search.</p>}
        {stores.map((store) => (
          <div key={store.id} className="store-card">
            <h3 className="store-name">{store.name}</h3>
            <p className="store-address">{store.address}</p>

            <div className="store-rating-row">
              <span className="store-rating-label">Overall Rating</span>
              <StarDisplay value={store.averageRating} count={store.ratingCount} />
            </div>

            <div className="store-rating-row">
              <span className="store-rating-label">
                {store.myRating ? 'Your Rating' : 'Rate This Store'}
              </span>
              <StarInput
                value={store.myRating || 0}
                disabled={savingId === store.id}
                onChange={(val) => handleRate(store.id, val)}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
