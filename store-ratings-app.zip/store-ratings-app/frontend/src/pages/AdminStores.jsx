import React, { useEffect, useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/axios';
import DataTable from '../components/DataTable';
import { StarDisplay } from '../components/StarRating';

export default function AdminStores() {
  const [stores, setStores] = useState([]);
  const [filters, setFilters] = useState({ name: '', email: '', address: '' });
  const [sortBy, setSortBy] = useState('name');
  const [sortOrder, setSortOrder] = useState('ASC');
  const [error, setError] = useState('');

  const fetchStores = useCallback(async () => {
    try {
      const params = { ...filters, sortBy, sortOrder };
      Object.keys(params).forEach((k) => !params[k] && delete params[k]);
      const { data } = await api.get('/admin/stores', { params });
      setStores(data.stores);
    } catch (err) {
      setError('Failed to load stores.');
    }
  }, [filters, sortBy, sortOrder]);

  useEffect(() => { fetchStores(); }, [fetchStores]);

  const handleSort = (key) => {
    if (sortBy === key) {
      setSortOrder(sortOrder === 'ASC' ? 'DESC' : 'ASC');
    } else {
      setSortBy(key);
      setSortOrder('ASC');
    }
  };

  const columns = [
    { key: 'name', label: 'Store Name', sortable: true },
    { key: 'email', label: 'Email', sortable: true },
    { key: 'address', label: 'Address', sortable: true },
    {
      key: 'averageRating',
      label: 'Rating',
      sortable: true,
      render: (row) => {
        const val = row.averageRating ? parseFloat(row.averageRating) : null;
        return <StarDisplay value={val} count={row.ratingCount ? parseInt(row.ratingCount, 10) : 0} />;
      },
    },
  ];

  return (
    <div className="page-container">
      <div className="page-header-row">
        <div>
          <h1 className="page-title">Manage Stores</h1>
          <p className="page-subtitle">Search, filter, and inspect all registered stores</p>
        </div>
        <Link to="/admin/stores/new" className="btn btn-primary">+ Add New Store</Link>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      <div className="filter-bar">
        <input placeholder="Filter by name" value={filters.name} onChange={(e) => setFilters({ ...filters, name: e.target.value })} />
        <input placeholder="Filter by email" value={filters.email} onChange={(e) => setFilters({ ...filters, email: e.target.value })} />
        <input placeholder="Filter by address" value={filters.address} onChange={(e) => setFilters({ ...filters, address: e.target.value })} />
      </div>

      <DataTable
        columns={columns}
        rows={stores}
        sortBy={sortBy}
        sortOrder={sortOrder}
        onSort={handleSort}
        emptyMessage="No stores match the current filters."
      />
    </div>
  );
}
