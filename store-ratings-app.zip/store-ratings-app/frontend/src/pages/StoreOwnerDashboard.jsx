import React, { useEffect, useState } from 'react';
import api from '../api/axios';
import DataTable from '../components/DataTable';
import { StarDisplay } from '../components/StarRating';

export default function StoreOwnerDashboard() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/stores/owner/dashboard')
      .then(({ data }) => setData(data))
      .catch((err) => setError(err.response?.data?.message || 'Failed to load dashboard.'));
  }, []);

  if (error) return <div className="page-container"><div className="alert alert-error">{error}</div></div>;
  if (!data) return <div className="page-container">Loading…</div>;

  const columns = [
    { key: 'name', label: 'Customer Name', render: (row) => row.user?.name },
    { key: 'email', label: 'Email', render: (row) => row.user?.email },
    { key: 'rating', label: 'Rating', render: (row) => <StarDisplay value={row.rating} /> },
    { key: 'submittedAt', label: 'Submitted On', render: (row) => new Date(row.submittedAt).toLocaleDateString() },
  ];

  return (
    <div className="page-container">
      <h1 className="page-title">{data.store.name}</h1>
      <p className="page-subtitle">{data.store.address}</p>

      <div className="stats-grid">
        <div className="stat-card">
          <span className="stat-value">{data.averageRating || '—'}</span>
          <span className="stat-label">Average Rating</span>
        </div>
        <div className="stat-card">
          <span className="stat-value">{data.totalRatings}</span>
          <span className="stat-label">Total Ratings Received</span>
        </div>
      </div>

      <h2 className="section-title">Customers Who Rated Your Store</h2>
      <DataTable columns={columns} rows={data.raters} emptyMessage="No ratings submitted yet." />
    </div>
  );
}
