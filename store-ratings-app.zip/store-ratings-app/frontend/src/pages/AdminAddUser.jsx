import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/axios';

export default function AdminAddUser() {
  const [form, setForm] = useState({ name: '', email: '', address: '', password: '', role: 'USER', storeId: '' });
  const [stores, setStores] = useState([]);
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (form.role === 'STORE_OWNER') {
      api.get('/admin/stores').then(({ data }) => setStores(data.stores)).catch(() => {});
    }
  }, [form.role]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const validate = () => {
    const errs = {};
    if (form.name.trim().length < 20 || form.name.trim().length > 60) {
      errs.name = 'Name must be between 20 and 60 characters';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      errs.email = 'Enter a valid email address';
    }
    if (form.address.trim().length === 0 || form.address.length > 400) {
      errs.address = 'Address is required (max 400 characters)';
    }
    if (!/^(?=.*[A-Z])(?=.*[!@#$%^&*(),.?":{}|<>_\-+=~`[\];'/\\]).{8,16}$/.test(form.password)) {
      errs.password = '8-16 characters, at least 1 uppercase letter and 1 special character';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setServerError('');
    setSuccess('');
    if (!validate()) return;

    setLoading(true);
    try {
      await api.post('/admin/users', form);
      setSuccess('User created successfully.');
      setTimeout(() => navigate('/admin/users'), 1000);
    } catch (err) {
      if (err.response?.data?.errors) setErrors(err.response.data.errors);
      else setServerError(err.response?.data?.message || 'Failed to create user.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container narrow">
      <h1 className="page-title">Add New User</h1>
      <p className="page-subtitle">Create a System Administrator, Normal User, or Store Owner account</p>

      <div className="card">
        {serverError && <div className="alert alert-error">{serverError}</div>}
        {success && <div className="alert alert-success">{success}</div>}

        <form onSubmit={handleSubmit} className="auth-form" noValidate>
          <label>
            Full Name
            <input type="text" name="name" value={form.name} onChange={handleChange} placeholder="20-60 characters" />
            {errors.name && <span className="field-error">{errors.name}</span>}
          </label>

          <label>
            Email
            <input type="email" name="email" value={form.email} onChange={handleChange} />
            {errors.email && <span className="field-error">{errors.email}</span>}
          </label>

          <label>
            Address
            <textarea name="address" value={form.address} onChange={handleChange} rows={3} maxLength={400} />
            {errors.address && <span className="field-error">{errors.address}</span>}
          </label>

          <label>
            Password
            <input type="password" name="password" value={form.password} onChange={handleChange} placeholder="8-16 chars, 1 uppercase, 1 special character" />
            {errors.password && <span className="field-error">{errors.password}</span>}
          </label>

          <label>
            Role
            <select name="role" value={form.role} onChange={handleChange}>
              <option value="USER">Normal User</option>
              <option value="ADMIN">System Administrator</option>
              <option value="STORE_OWNER">Store Owner</option>
            </select>
          </label>

          {form.role === 'STORE_OWNER' && (
            <label>
              Link to Existing Store (optional)
              <select name="storeId" value={form.storeId} onChange={handleChange}>
                <option value="">-- No store linked yet --</option>
                {stores.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </label>
          )}

          <button type="submit" className="btn btn-primary btn-block" disabled={loading}>
            {loading ? 'Creating…' : 'Create User'}
          </button>
        </form>
      </div>
    </div>
  );
}
