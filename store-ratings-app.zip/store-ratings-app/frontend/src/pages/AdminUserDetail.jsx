import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../api/axios';
import { StarDisplay } from '../components/StarRating';

const roleLabels = { ADMIN: 'System Administrator', USER: 'Normal User', STORE_OWNER: 'Store Owner' };

export default function AdminUserDetail() {
  const { id } = useParams();
  const [user, setUser] = useState(null);
  const [rating, setRating] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get(`/admin/users/${id}`)
      .then(({ data }) => {
        setUser(data.user);
        setRating(data.rating);
      })
      .catch(() => setError('Failed to load user details.'));
  }, [id]);

  if (error) return <div className="page-container"><div className="alert alert-error">{error}</div></div>;
  if (!user) return <div className="page-container">Loading…</div>;

  return (
    <div className="page-container narrow">
      <Link to="/admin/users" className="link-back">← Back to Users</Link>
      <h1 className="page-title">User Details</h1>

      <div className="card detail-card">
        <div className="detail-row"><span>Name</span><strong>{user.name}</strong></div>
        <div className="detail-row"><span>Email</span><strong>{user.email}</strong></div>
        <div className="detail-row"><span>Address</span><strong>{user.address}</strong></div>
        <div className="detail-row"><span>Role</span><strong><span className={`badge badge-${user.role.toLowerCase()}`}>{roleLabels[user.role]}</span></strong></div>

        {user.role === 'STORE_OWNER' && (
          <div className="detail-row">
            <span>Store Rating</span>
            <strong>
              {rating && rating.average ? (
                <StarDisplay value={parseFloat(rating.average)} count={rating.count} />
              ) : (
                'No ratings yet'
              )}
            </strong>
          </div>
        )}
      </div>
    </div>
  );
}
