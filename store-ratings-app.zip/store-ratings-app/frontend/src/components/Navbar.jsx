import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const roleLabels = {
  ADMIN: 'Administrator',
  USER: 'Customer',
  STORE_OWNER: 'Store Owner',
};

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const homeLink =
    user?.role === 'ADMIN' ? '/admin/dashboard'
    : user?.role === 'STORE_OWNER' ? '/owner/dashboard'
    : '/stores';

  return (
    <header className="navbar">
      <div className="navbar-top">
        <Link to={user ? homeLink : '/login'} className="brand">
          <span className="brand-mark">Store</span><span className="brand-accent">Rate</span>
        </Link>

        {user && (
          <nav className="navbar-links">
            {user.role === 'ADMIN' && (
              <>
                <Link to="/admin/dashboard">Dashboard</Link>
                <Link to="/admin/users">Users</Link>
                <Link to="/admin/stores">Stores</Link>
              </>
            )}
            {user.role === 'USER' && (
              <>
                <Link to="/stores">Browse Stores</Link>
                <Link to="/update-password">Account</Link>
              </>
            )}
            {user.role === 'STORE_OWNER' && (
              <>
                <Link to="/owner/dashboard">My Store</Link>
                <Link to="/update-password">Account</Link>
              </>
            )}
          </nav>
        )}

        <div className="navbar-right">
          {user ? (
            <>
              <span className="navbar-user">
                Hello, {user.name.split(' ')[0]}
                <small>{roleLabels[user.role]}</small>
              </span>
              <button className="btn btn-outline" onClick={handleLogout}>Sign Out</button>
            </>
          ) : (
            <Link to="/login" className="btn btn-outline">Sign In</Link>
          )}
        </div>
      </div>
    </header>
  );
}
