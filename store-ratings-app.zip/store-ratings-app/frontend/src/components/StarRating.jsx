import React, { useState } from 'react';

// Read-only star display (supports decimals like 4.3)
export function StarDisplay({ value, count }) {
  if (value === null || value === undefined) {
    return <span className="star-display star-display-empty">No ratings yet</span>;
  }
  const stars = [1, 2, 3, 4, 5].map((i) => {
    const filled = value >= i;
    const half = !filled && value >= i - 0.5;
    return (
      <span key={i} className={`star ${filled ? 'star-filled' : half ? 'star-half' : 'star-empty'}`}>★</span>
    );
  });
  return (
    <span className="star-display" title={`${value} out of 5`}>
      {stars}
      <span className="star-value">{value.toFixed(1)}{count !== undefined ? ` (${count})` : ''}</span>
    </span>
  );
}

// Interactive 1-5 star picker used to submit/update a rating
export function StarInput({ value, onChange, disabled }) {
  const [hover, setHover] = useState(0);

  return (
    <span className="star-input">
      {[1, 2, 3, 4, 5].map((i) => (
        <span
          key={i}
          role="button"
          aria-label={`Rate ${i} star${i > 1 ? 's' : ''}`}
          className={`star star-clickable ${(hover || value) >= i ? 'star-filled' : 'star-empty'}`}
          onMouseEnter={() => !disabled && setHover(i)}
          onMouseLeave={() => !disabled && setHover(0)}
          onClick={() => !disabled && onChange(i)}
        >
          ★
        </span>
      ))}
    </span>
  );
}
