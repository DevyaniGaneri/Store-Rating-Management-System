import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import PrivateRoute from './components/PrivateRoute';
import Navbar from './components/Navbar';

import Login from './pages/Login';
import Signup from './pages/Signup';
import UpdatePassword from './pages/UpdatePassword';

import AdminDashboard from './pages/AdminDashboard';
import AdminUsers from './pages/AdminUsers';
import AdminAddUser from './pages/AdminAddUser';
import AdminUserDetail from './pages/AdminUserDetail';
import AdminStores from './pages/AdminStores';
import AdminAddStore from './pages/AdminAddStore';

import StoreList from './pages/StoreList';
import StoreOwnerDashboard from './pages/StoreOwnerDashboard';

import './styles/app.css';

function HomeRedirect() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role === 'ADMIN') return <Navigate to="/admin/dashboard" replace />;
  if (user.role === 'STORE_OWNER') return <Navigate to="/owner/dashboard" replace />;
  return <Navigate to="/stores" replace />;
}

function AppRoutes() {
  return (
    <BrowserRouter>
      <Navbar />
      <main className="app-main">
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />

          <Route path="/update-password" element={
            <PrivateRoute><UpdatePassword /></PrivateRoute>
          } />

          {/* Administrator routes */}
          <Route path="/admin/dashboard" element={
            <PrivateRoute allowedRoles={['ADMIN']}><AdminDashboard /></PrivateRoute>
          } />
          <Route path="/admin/users" element={
            <PrivateRoute allowedRoles={['ADMIN']}><AdminUsers /></PrivateRoute>
          } />
          <Route path="/admin/users/new" element={
            <PrivateRoute allowedRoles={['ADMIN']}><AdminAddUser /></PrivateRoute>
          } />
          <Route path="/admin/users/:id" element={
            <PrivateRoute allowedRoles={['ADMIN']}><AdminUserDetail /></PrivateRoute>
          } />
          <Route path="/admin/stores" element={
            <PrivateRoute allowedRoles={['ADMIN']}><AdminStores /></PrivateRoute>
          } />
          <Route path="/admin/stores/new" element={
            <PrivateRoute allowedRoles={['ADMIN']}><AdminAddStore /></PrivateRoute>
          } />

          {/* Normal user routes */}
          <Route path="/stores" element={
            <PrivateRoute allowedRoles={['USER']}><StoreList /></PrivateRoute>
          } />

          {/* Store owner routes */}
          <Route path="/owner/dashboard" element={
            <PrivateRoute allowedRoles={['STORE_OWNER']}><StoreOwnerDashboard /></PrivateRoute>
          } />

          <Route path="/" element={<HomeRedirect />} />
          <Route path="*" element={<HomeRedirect />} />
        </Routes>
      </main>
    </BrowserRouter>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppRoutes />
    </AuthProvider>
  );
}
