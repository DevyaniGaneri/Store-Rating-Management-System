# StoreRate — Store Rating Platform

A full-stack web application where customers rate stores (1–5), store owners
track their ratings, and administrators manage the whole platform.

**Stack:** Node.js + Express (backend) · PostgreSQL + Sequelize (database) ·
React (frontend) · JWT authentication

---

## 1. Project Structure

```
store-ratings-app/
├── backend/          Express API server
│   ├── config/        Database connection
│   ├── controllers/   Route logic (auth, admin, stores, ratings)
│   ├── middleware/     JWT auth + role guards
│   ├── models/          Sequelize models (User, Store, Rating)
│   ├── routes/            API routes
│   ├── seed/              Script to create the first admin account
│   ├── .env.example
│   └── server.js
└── frontend/         React application
    ├── public/
    ├── src/
    │   ├── api/            Axios instance (attaches JWT automatically)
    │   ├── components/     Navbar, DataTable, StarRating, PrivateRoute
    │   ├── context/        Auth context (login state)
    │   ├── pages/          One file per screen (Login, Dashboards, etc.)
    │   └── styles/app.css  Global design system
    └── .env.example
```

---

## 2. Prerequisites

Install these once on your machine before you start:

1. **Node.js** version 18 or later — check with `node -v`
2. **PostgreSQL** version 13 or later — check with `psql --version`
   - Windows/Mac: install from https://www.postgresql.org/download/
   - Make sure the PostgreSQL service is running

---

## 3. Step-by-Step Setup

### Step 1 — Unzip the project

Unzip `store-ratings-app.zip` anywhere on your computer, then open a terminal
in that folder.

### Step 2 — Create the PostgreSQL database

Open a terminal and log in to PostgreSQL:

```bash
psql -U postgres
```

Then create the database (you only need to do this once):

```sql
CREATE DATABASE store_ratings_db;
\q
```

### Step 3 — Configure and install the backend

```bash
cd backend
cp .env.example .env
```

Open the new `.env` file in any text editor and update these values to match
your PostgreSQL setup:

```
DB_NAME=store_ratings_db
DB_USER=postgres
DB_PASSWORD=your_postgres_password
DB_HOST=127.0.0.1
DB_PORT=5432
JWT_SECRET=replace_this_with_a_long_random_secret_string
```

You can also change `ADMIN_EMAIL` / `ADMIN_PASSWORD` in that same file — this
is the login you'll use for the very first System Administrator account.

Now install dependencies:

```bash
npm install
```

### Step 4 — Create the database tables and the first admin account

```bash
npm run seed
```

This connects to PostgreSQL, creates all tables (`users`, `stores`,
`ratings`) automatically, and creates one System Administrator account using
the `ADMIN_*` values from your `.env` file. You'll see a confirmation with
the admin email/password in the terminal.

### Step 5 — Start the backend server

```bash
npm run dev
```

You should see:
```
Database connection established successfully.
Database synced.
Server running on http://localhost:5000
```

Leave this terminal window open and running.

### Step 6 — Configure and install the frontend

Open a **new** terminal window (keep the backend running in the first one):

```bash
cd frontend
cp .env.example .env
npm install
```

The default `.env` already points to `http://localhost:5000/api`, which
matches the backend from Step 5 — no changes needed unless you changed the
backend `PORT`.

### Step 7 — Start the frontend

```bash
npm start
```

Your browser will open automatically at **http://localhost:3000**.

### Step 8 — Log in

Use the admin credentials from Step 4 (`ADMIN_EMAIL` / `ADMIN_PASSWORD` in
`backend/.env`, default `admin@storeratings.com` / `Admin@1234`) to log in as
the System Administrator. From there you can:

- Add new stores (Admin Dashboard → **+ Add New Store**)
- Add Store Owner and other Admin accounts (Admin Dashboard → **+ Add New User**)
- Anyone else can self-register as a Normal User from the **Sign Up** page

---

## 4. Everyday Usage (after the first setup)

Each time you want to run the app again:

**Terminal 1:**
```bash
cd backend
npm run dev
```

**Terminal 2:**
```bash
cd frontend
npm start
```

That's it — no need to run `npm run seed` again unless you want a fresh
database.

---

## 5. Feature Summary

| Role | Capabilities |
|---|---|
| **System Administrator** | Dashboard (user/store/rating counts), add users & stores, view/filter/sort all users and stores, view user detail (with store rating for Store Owners) |
| **Normal User** | Sign up, log in, browse & search stores, submit/update a 1–5 rating, update password |
| **Store Owner** | Log in, view average rating & list of raters for their store, update password |

**Validation rules enforced (frontend + backend):**
- Name: 20–60 characters
- Address: up to 400 characters
- Password: 8–16 characters, at least one uppercase letter and one special character
- Email: standard email format

All listing tables support column sorting (ascending/descending) and, where
specified, filtering by Name / Email / Address / Role.

---

## 6. Troubleshooting

- **`Unable to start server` / connection refused** — PostgreSQL isn't
  running, or the credentials in `backend/.env` don't match your local
  PostgreSQL user/password.
- **`role "postgres" does not exist`** — use whichever PostgreSQL username
  you actually have (find it with `psql -U your_username -l`), and put that
  in `DB_USER`.
- **Frontend loads but API calls fail / CORS error** — make sure the backend
  (Step 5) is running before you start the frontend, and that
  `REACT_APP_API_URL` in `frontend/.env` matches the backend's port.
- **Port already in use** — change `PORT` in `backend/.env` (and update
  `REACT_APP_API_URL` in `frontend/.env` to match), or stop whatever else is
  using port 5000/3000.
